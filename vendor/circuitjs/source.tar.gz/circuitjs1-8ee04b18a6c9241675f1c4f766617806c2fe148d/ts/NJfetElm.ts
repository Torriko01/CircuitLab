export { NJfetElm } from "./JfetElm";
