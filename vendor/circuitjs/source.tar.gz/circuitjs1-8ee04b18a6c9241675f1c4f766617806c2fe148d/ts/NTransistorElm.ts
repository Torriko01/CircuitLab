export { NTransistorElm } from "./TransistorElm";
