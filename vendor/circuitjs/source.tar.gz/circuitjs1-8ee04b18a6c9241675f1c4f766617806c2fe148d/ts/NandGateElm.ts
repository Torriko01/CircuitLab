export { NandGateElm } from "./GateElm";
