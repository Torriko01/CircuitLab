export { NorGateElm } from "./GateElm";
