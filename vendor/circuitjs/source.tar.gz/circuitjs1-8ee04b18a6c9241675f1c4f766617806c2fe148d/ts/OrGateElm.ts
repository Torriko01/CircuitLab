export { OrGateElm } from "./GateElm";
