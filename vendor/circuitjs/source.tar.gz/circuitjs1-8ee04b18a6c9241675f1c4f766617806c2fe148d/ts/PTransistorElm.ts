export { PTransistorElm } from "./TransistorElm";
