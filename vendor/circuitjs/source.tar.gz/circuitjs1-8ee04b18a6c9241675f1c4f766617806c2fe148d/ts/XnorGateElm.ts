export { XnorGateElm } from "./GateElm";
