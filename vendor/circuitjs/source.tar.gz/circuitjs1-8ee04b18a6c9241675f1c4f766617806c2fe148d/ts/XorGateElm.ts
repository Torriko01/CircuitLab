export { XorGateElm } from "./GateElm";
